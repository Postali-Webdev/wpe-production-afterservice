<?php
/*
 * Template Name: Homepage
 */
 ?>

<?php get_header();?>

    <!-- Section 1 - Content 1
     --------------------------------------------------------------------------------------- -->

    <section id="section-1">
        <div class="section-1-container">
            <div class="section-1-left">
                <h1>Nationwide <span>VA Disability</span> Lawyer</h1>

                <div class="section-1-left-top-content">
                    <?php the_field('section_1_left_top_content'); ?>
                </div>

                <b class="section-1-blockquote"><?php the_field('section_1_left_blockquote'); ?></b>

                <div class="section-1-left-content">
                    <?php the_field('section_1_left_content'); ?>
                </div>
            </div>

            <div class="section-1-right">
                <div class="section-1-right-image">
                    <div class="section-1-right-image-content">
                        <h4 class="wow fadeInRight">I served in the<br> Air Force for six years.</h4>
                        <i class="wow fadeInRight" data-wow-delay="0.15s">Now, I represent fellow veterans against the Veterans<br> Administration, the Board of Veterans’ Appeals,<br> and the U.S. Court of Appeals for Veterans Claims.</i>
                        <div class="section-1-right-image-button wow fadeInRight" data-wow-delay="0.3s">
                            <a href="#footer-form">CLICK HERE FOR A FREE CONSULTATION</a>
                            <img class="svg" src="/wp-content/themes/rada/images/button-circle-01.svg">
                            <img class="svg" src="/wp-content/themes/rada/images/button-arrow-01.svg">
                        </div>
                    </div>
                </div>

                <div class="section-1-right-content">
                    <?php the_field('section_1_right_content'); ?>
                </div>
            </div>
        </div>
    </section>

<!-- RESULTS SECTION
     --------------------------------------------------------------------------------------- -->

<section class="result-wrap">
	<h2>
		CASE RESULTS
	</h2>
      <div class="result-columns" style="">
        <?php echo do_shortcode("[slide-anything id='2638']"); ?>

	</div>
    </section>




    <!-- Section 2 - Testimonials
     ----------------------------------------------------------------------------------------->

    <section id="section-2">
        <div class="section-2-container clearfix">
            <h4 class="section-2-header wow fadeInLeft">TESTIMONIALS</h4>

            <div class="section-2-content">
                <div class="testimonials-slider wow fadeInRight">
                    <?php if( have_rows('homepage_testimonials') ): while ( have_rows('homepage_testimonials') ) : the_row(); ?>
                        <div class="testimonial-box">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/test-stars.png">
                            <h3><?php the_sub_field('testimonial_header'); ?></h3>
                            <p><?php the_sub_field('testimonial_content'); ?></p>
                            <h5><?php the_sub_field('testimonial_author'); ?></h5>
                        </div>
                    <?php endwhile; else : endif; ?>
                </div>

                <div id="section-2-left-arrow">
                    <img class="svg" src="/wp-content/themes/rada/images/button-circle-01.svg">
                    <img class="svg" src="/wp-content/themes/rada/images/button-arrow-01.svg">
                </div>

                <div id="section-2-right-arrow">
                    <img class="svg" src="/wp-content/themes/rada/images/button-circle-01.svg">
                    <img class="svg" src="/wp-content/themes/rada/images/button-arrow-01.svg">
                </div>

                <div class="slick-number-count">
                    <span class="pagingInfo"></span>
                </div>
            </div>
        </div>
    </section>

    <section class="video-testimonial-wrap">
      <div class="video-testimonial">
        <div class="video-testimonial-container clearfix">
          <div class="videoWrapper wow fadeInLeft">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/4wYteDSKE7g" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </section>

<!----------PROCESS SECTION ---------->




<section class="process-wrap">
	<h2>
		WORKING WITH ME
	</h2>
      <div class="process-columns">
        
		  
		  <div class="single-process clearfix">
          <h3>
			  Step 1
			</h3>
			  <h5>
			  Initial Consultation
			</h5>
			<p>
				We will discuss your case so I can understand your goals. If I can help you achieve your objectives, I will offer to represent you before the VA.
			</p>
			
			
			
		
        </div>
		  
		  <div class="single-process clearfix">
          <h3>
			  Step 2
			</h3>
			  
			  <h5>
			  Initiation of Representation
			</h5>
			  
			<p>
				I will draft the representation paperwork and email it to you to electronically sign and date. Then, I will countersign the documents at which point I become your attorney.
			</p>
			
			
			
		
        </div>
		  
		  <div class="single-process clearfix">
          <h3>
			  Step 3
			</h3>
			  
			  <h5>
			 Claims File Review
			</h5>
			  
			<p>
				Reviewing your VA claims file is the most important step because I may find previous errors that VA made in your case and because it guides us with how to appeal.
			</p>
			
			
			
		
        </div>
		  
		  <div class="single-process clearfix">
          <h3>
			  Step 4
			</h3>
			  
			  <h5>
			  Client/Attorney Conference
			</h5>
			  
			<p>
				We will discuss the findings from my review of your VA claims file and then discuss the path forward regarding your appeal.
			</p>
			
			
			
		
        </div>
		  
		  <div class="single-process clearfix">
          <h3>
			  Step 5
			</h3>
			  <h5>
			 Evidence Development
			</h5>
			<p>
				We will develop the evidence needed to win your appeal such as drafting lay statements, obtaining independent medical opinions, or obtaining vocational expert opinions.
			</p>
			
			
			
		
        </div>
		  
		  <div class="single-process clearfix">
          <h3>
			  Step 6
			</h3>
			  
			  <h5>
			  Submit Evidence and Argument
			</h5>
			  
			<p>
				I will file your appeal with a legal brief and the evidence we developed. We then wait for the VA's decision.
			</p>
			
			
			
		
        </div>
		  
      </div>
    </section>



    <!-- Section 3 - Content 2
     ----------------------------------------------------------------------------------------->

    <div id="section-3">
        <div class="section-3-left">
            <div class="section-3-left-container">
                <img class="wow zoomIn" src="<?php echo get_stylesheet_directory_uri(); ?>/images/pa-stamp.png">
                <?php wp_nav_menu( array('menu' => 'Home Practice Areas Menu' )); ?>
            </div>

        </div>

        <div class="section-3-right">
            <div class="section-3-right-container">
                <h2>Veteran Experience &amp; <span>Disability Experience</span></h2>
                <div class="section-3-right-content">
                    <div class="section-3-right-left">
                        <?php the_field('homepage_section_3_content'); ?>
                    </div>

                    <div class="section-3-right-right wow fadeIn" data-wow-duration="1s">
                        <div class="section-3-right-right-content">
                            <h4>SERVING THE WHOLE COUNTRY</h4>
                            <a href="#footer-form"><em><b>click</b><i>tap</i> here</em> for a free consultation</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>



<?php get_footer();?>
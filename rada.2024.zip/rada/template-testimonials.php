<?php
/*
 * Template Name: Testimonials
 */
?>

<?php get_header();?>

    <div class="testimonials-page-header">
        <h1>TESTIMONIALS</h1>
    </div>

    <div class="testimonials-page">
        <div class="testimonials-page-container">
            <?php if( have_rows('testimonials_page') ): while ( have_rows('testimonials_page') ) : the_row(); ?>
                <div class="testimonials-item">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/test-stars.png">
                    <h3><?php the_sub_field('testimonial_header'); ?></h3>
                    <p><?php the_sub_field('testimonial_content'); ?></p>
                    <h4><?php the_sub_field('testimonial_author'); ?></h4>
                </div>
            <?php endwhile; else : endif; ?>
        </div>
    </div>

<?php get_footer();?>
<?php
/*
 * Template Name: Bio
 */
?>

<?php get_header();?>

    <div class="bio-page">
        <div class="bio-page-container">
            <div class="bio-left">
                <h1>Gregory <span>Rada</span></h1>
                <img class="tablet-only" src="<?php echo get_stylesheet_directory_uri(); ?>/images/int-bio-profile.jpg">
                <img class="mobile-only" src="<?php echo get_stylesheet_directory_uri(); ?>/images/int-bio-profile-mobile.jpg">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_content(); ?>
                <?php endwhile; // end of the loop. ?>
            </div>

            <div class="bio-right">
                <img class="desktop-only" src="<?php echo get_stylesheet_directory_uri(); ?>/images/int-bio-profile.jpg">

				<h4>Contact</h4>
                <h5>greg@afterservice.com</h5>
				
                <h4>EDUCATION</h4>
                <h5>The University of Connecticut School of Law</h5>
                <p>J.D. with honors</p>

                <h5>The University of Phoenix</h5>
                <p>B.S., Information Technology</p>

                <h5>Community College of the Air Force</h5>
                <p>A.A.S., Aviation Operations</p>


                <h4>ADMISSIONS</h4>
                <ul>
                    <li>State of Colorado</li>
                    <li>United States Court of Appeals for Veterans’ Claims</li>
                    <li>United States District Court, District of Colorado</li>
                    <li>Veterans Affairs Accredited Attorney</li>
                </ul>

                <h4>Professional Associations</h4>
                <ul>
                    <li>National Organization of Veterans Advocates, Member</li>
                    <li>Veterans Consortium Pro Bono Program, Volunteer</li>
                    <li>Colorado Lawyers for Colorado Veterans, Volunteer</li>
                </ul>
            </div>
        </div>
    </div>

<?php get_footer();?>
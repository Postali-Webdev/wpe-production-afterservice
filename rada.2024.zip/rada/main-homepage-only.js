/* Functions that run on the homepage only. */

jQuery(document).ready(function(){







    /* Homepage Testimonials Slider
     --------------------------------------------------------------------------------------- */
    var $status = jQuery('.pagingInfo');
    var $slickElement = jQuery('.testimonials-slider');

    $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
        //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
        var i = (currentSlide ? currentSlide : 0) + 1;
        $status.html("0" + i + '<b>/</b>' + "0" + slick.slideCount);
    });

    jQuery('.testimonials-slider').slick({
        autoplay: true,
        autoplaySpeed: 8000,
        dots: false,
        slidesToShow: 1,
        sidesToScroll: 1,
        arrows: true,
        prevArrow: '#section-2-left-arrow',
        nextArrow: '#section-2-right-arrow',
        useTransform: true,
        cssEase: 'ease-in-out',
        speed: 1000
    });










    /* End Document Ready
     --------------------------------------------------------------------------------------- */

});


<?php
/*
 * Template Name: Bio John
 */
?>

<?php get_header();?>

    <div class="bio-page">
        <div class="bio-page-container">
            <div class="bio-left">
                <h1>John J.<span>Duguay</span></h1>
                <img class="tablet-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <img class="mobile-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_content(); ?>
                <?php endwhile; // end of the loop. ?>
            </div>

            <div class="bio-right">
              <img class="desktop-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
				
				<h4>Contact</h4>
                <h5>john@afterservice.com</h5>

              <h4>EDUCATION</h4>
              <h5>University of Connecticut School of Law</h5>
              <p>J.D.</p>

              <h5>University of Vermont</h5>
              <p>B.A., Economics</p>


              <h4>ADMISSIONS</h4>
              <ul>
                <li>State of Colorado </li>
                <li>United States District Court, District of Colorado</li>
              </ul>

              <h4>Professional Associations</h4>
              <ul>
                <li>National Organization of Veterans Advocates, Member</li>
                <li>Colorado Trial Lawyers Association</li>
                <li>Veterans Consortium Pro Bono Program, Volunteer</li>
              </ul>
            </div>
        </div>
    </div>

<?php get_footer();?>
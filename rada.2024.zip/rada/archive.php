<?php
/*
 * Template for displaying blog posts in the specific category.
 */
?>

<?php get_header();?>

    <div class="blog-page">
        <div class="blog-main">
            <h1><?php the_archive_title();?></h1>

            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <div class="blog-post">
                    <p class="blog-title"><a href="<?php the_permalink();?>" class=""><?php the_title();?></a></p>
                    <p class="blog-time">Posted by Gregory M. Rada <span>|</span> <?php the_time('F j, Y'); ?> <span>|</span> <?php the_category(',');?></p>
                    <?php the_excerpt();?>
                </div>
            <?php endwhile; else : ?>
                <p><?php ( 'Sorry, no posts matched your criteria.' ); ?></p>
            <?php endif; ?>

            <div class="navigation"><p><?php posts_nav_link(' - ','« Previous Page','Next Page »'); ?></p></div>
        </div>

        <div class="blog-sidebar">
            <?php dynamic_sidebar( 'blog-sidebar' ); ?>
        </div>
    </div>

<?php get_footer();?>
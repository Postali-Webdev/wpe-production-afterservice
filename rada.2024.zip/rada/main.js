/* Functions that run on all pages. */

jQuery(document).ready(function(){


    /* Resize Functions
     --------------------------------------------------------------------------------------- */
    var resizeTimer;
    jQuery(window).on('resize', function() {

        clearTimeout(resizeTimer)

        resizeTimer = setTimeout(function() {
            checkWidthTablet();

        }, 5)

    })





    /* Mobile Menu
     --------------------------------------------------------------------------------------- */

    jQuery(".header-top-menu-button").click(function(){
        jQuery(".header-top-nav").slideToggle();
    });

    jQuery('#menu-main-menu > .menu-item-has-children > .sub-menu').addClass('first-sub');
    jQuery('#menu-main-menu .menu-item-has-children .sub-menu .menu-item-has-children .sub-menu').addClass('last-sub');

    jQuery('#menu-main-menu > .menu-item-has-children a').click(function(){
        jQuery(this).siblings('.first-sub').slideToggle();
        jQuery(this).closest('.menu-item-has-children').siblings().find('.sub-menu').slideUp();
    });

    jQuery('#menu-main-menu > .menu-item-has-children > .first-sub > .menu-item-has-children a').click(function(){
        jQuery(this).siblings('.last-sub').slideToggle();
    });





    /* Accordion Dropdown Menu for Sidebar Menu in Internal Page
     --------------------------------------------------------------------------------------- */

    jQuery('#menu-sidebar-menu > .menu-item-has-children > .sub-menu').addClass('first-sub');
    jQuery('#menu-sidebar-menu .menu-item-has-children .sub-menu .menu-item-has-children .sub-menu').addClass('last-sub');

    jQuery('#menu-sidebar-menu > .menu-item-has-children a').click(function(){
        jQuery(this).siblings('.first-sub').slideToggle();
    });

    jQuery('#menu-sidebar-menu > .menu-item-has-children > .first-sub > .menu-item-has-children a').click(function(){
        jQuery(this).siblings('.last-sub').slideToggle();
    });







    /* Smooth Scroll
     --------------------------------------------------------------------------------------- */

        jQuery(function() {
            jQuery('a[href*="#"]:not([href="#"])').click(function() {
                if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
                    var target = jQuery(this.hash);
                    target = target.length ? target : jQuery('[name=' + this.hash.slice(1) +']');
                    if (target.length) {
                        jQuery('html, body').animate({
                            scrollTop: target.offset().top
                        }, 1000);
                        return false;
                    }
                }
            });
        });





    /* Convert .svg file to html svg on page load.
       Will turn <img src="image.svg"> to <svg>(svg code)</svg>
       To use: add class svg to image tag. ex: <img src="image.svg" class="svg">
     --------------------------------------------------------------------------------------- */

        jQuery('img.svg').each(function(){
            var $img = jQuery(this);
            var imgID = $img.attr('id');
            var imgClass = $img.attr('class');
            var imgURL = $img.attr('src');

            jQuery.get(imgURL, function(data) {
                // Get the SVG tag, ignore the rest
                var $svg = jQuery(data).find('svg');

                // Add replaced image's ID to the new SVG
                if(typeof imgID !== 'undefined') {
                    $svg = $svg.attr('id', imgID);
                }
                // Add replaced image's classes to the new SVG
                if(typeof imgClass !== 'undefined') {
                    $svg = $svg.attr('class', imgClass+' replaced-svg');
                }

                // Remove any invalid XML tags as per http://validator.w3.org
                $svg = $svg.removeAttr('xmlns:a');

                // Replace image with new SVG
                $img.replaceWith($svg);

            }, 'xml');

        });






    /* Waypoints
     --------------------------------------------------------------------------------------- */

    function createWaypoint (triggerElementId, animatedElement, className, offsetVal, functionName, reverse) {
        var waypoint = new Waypoint({
            element: document.getElementById(triggerElementId),
            handler: function(direction) {
                if (direction === 'down') {
                    jQuery(animatedElement).addClass(className);

                    if(typeof functionName === 'function') {
                        functionName.call();
                    }
                }

                else {

                    if(reverse) {
                        jQuery(animatedElement).removeClass(className);

                        if(typeof functionName === 'function') {
                            functionName.call();
                        }
                    }

                }
            },
            offset: offsetVal
            // Integer or percent
            // 500 means when element is 500px from the top of the page, the event triggers
            // 50% means when element is 50% from the top of the page, the event triggers
        });
    }

    //Waypoint Instance - Add Class To Element
    //Template -> createWaypoint("id-name", ".class-name", "class-to-be-added", offset-value, null, true);
    //Example -> createWaypoint("section-2", ".section-2-orange-dot", "section-2-orange-dot-active", 500, null, true);

    //Waypoint Instance - Call Function
    //Template -> createWaypoint("id-name", null, null, 0, function-name, true);
    //Example -> createWaypoint("section-2", null, null, 0, test, true);




    /* Wow.js
     --------------------------------------------------------------------------------------- */

    new WOW().init();







    /* Misc
     --------------------------------------------------------------------------------------- */

    function checkWidthTablet() {
        if (jQuery(window).width() > 1199) {
            jQuery(".header-top-nav ul .sub-menu").hover(
                function() {
                    jQuery(this).parent().addClass("header-top-nav-item-active");
                },
                function() {
                    jQuery(this).parent().removeClass("header-top-nav-item-active");
                }
            );
        } else {

        }
    }
    checkWidthTablet();






    /* End Document Ready
     --------------------------------------------------------------------------------------- */

}); 


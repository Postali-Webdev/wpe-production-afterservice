<?php
/*
 * Default Template
 */
?>

<?php get_header();?>

    <div class="default-page">
        <div class="default-page-container">
            <div class="default-main">
                <h1><?php the_title();?></h1>

                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <?php the_content();?>
                <?php endwhile; else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
                <?php endif; ?>

            </div>

            <div class="default-sidebar">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/pa-stamp.png">
                <?php wp_nav_menu( array('menu' => 'Practice Areas Menu' )); ?>
            </div>
        </div>
    </div>

<?php get_footer();?>
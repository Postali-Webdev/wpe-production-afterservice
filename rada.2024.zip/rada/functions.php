<?php

/* Enqueue Scripts and Styles
 --------------------------------------------------------------------------------------- */

function theme_name_scripts() {

    wp_enqueue_style( 'style.css', get_template_directory_uri() . '/style.css' );

    wp_deregister_script('jquery');
    wp_register_script( 'jquery', includes_url( '/js/jquery/jquery.js' ), false, NULL, false );
    wp_enqueue_script(' jquery' );

    wp_enqueue_script( 'smoothScroll.min.js', get_template_directory_uri() . '/js/smoothScroll.min.js', array( 'jquery' ), '', true );
    wp_enqueue_script( 'slick.min.js', get_template_directory_uri() . '/js/slick.min.js', array( 'jquery' ), '', true );
    wp_enqueue_script( 'wow.min.js', get_template_directory_uri() . '/js/wow.min.js', array( 'jquery' ), '', true );
    wp_enqueue_script( 'waypoints.min.js', get_template_directory_uri() . '/js/waypoints.min.js', array( 'jquery' ), '', true );
    wp_enqueue_script( 'main.js', get_template_directory_uri() . '/main.js', array( 'jquery' ), '', true );

    if( is_page_template( 'template-home.php' ) ){
        wp_enqueue_script( 'main-homepage-only.js', get_template_directory_uri() . '/main-homepage-only.js', array( 'jquery' ), '', true );
    }

    if( !is_page_template( 'template-home.php' ) ){
        wp_enqueue_script( 'main-internals-only.js', get_template_directory_uri() . '/main-internals-only.js', array( 'jquery' ), '', true );
    }

}

add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );





/* Register Nav-Menus
 --------------------------------------------------------------------------------------- */

register_nav_menus( array(
    'main_menu' => 'Main Menu',
    'sidebar_menu' => 'Sidebar Menu',
    'practice_area_menu' => 'Practice Area Menu',
) );





/* No Tab Conflicts Gravity Forms
 --------------------------------------------------------------------------------------- */

add_filter( 'gform_tabindex', 'gform_tabindexer', 10, 2 );
function gform_tabindexer( $tab_index, $form = false ) {
    $starting_index = 1000; // if you need a higher tabindex, update this number
    if( $form )
        add_filter( 'gform_tabindex_' . $form['id'], 'gform_tabindexer' );
    return GFCommon::$tab_index >= $starting_index ? GFCommon::$tab_index : $starting_index;
}





/* Blog Sidebar Widget
 --------------------------------------------------------------------------------------- */

if(function_exists('register_sidebars')){

    register_sidebar(array(
        'name'          => 'Blog Sidebar',
        'id'            => 'blog_sidebar',
        'description'   => '',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widgettitle">',
        'after_title'   => '</h3>'
    ));
}





/* Add Theme Support Page Thumbnails
 --------------------------------------------------------------------------------------- */

add_theme_support( 'post-thumbnails' );





/* Modify the_excerpt() "read more"
 --------------------------------------------------------------------------------------- */

function new_excerpt_more($more) {
    global $post;
    return '... <a href="'. get_permalink($post->ID) . '">' . 'read more' . '</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');





/* Theme Options for ACF
 --------------------------------------------------------------------------------------- */

if( function_exists('acf_add_options_page') ) {

    acf_add_options_page(array(
        'page_title' 	=> 'Theme Options',
        'menu_title'	=> 'Theme Options',
        'menu_slug' 	=> 'theme-options',
        'capability'	=> 'edit_posts',
        'redirect'		=> false
    ));

}






/* Allow SVG to get uploaded to media library
 --------------------------------------------------------------------------------------- */

function cc_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'cc_mime_types');






/* Remove unnecessary scripts automatically loaded in the header by Wordpress
 --------------------------------------------------------------------------------------- */

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_styles', 'print_emoji_styles');





/* Remove WP version parameter from any enqueued scripts or stylesheets (version number)
 --------------------------------------------------------------------------------------- */

function vc_remove_wp_ver_css_js( $src ) {
    if ( strpos( $src, 'ver=' . get_bloginfo( 'version' ) ) )
        $src = remove_query_arg( 'ver', $src );
    return $src;
}
add_filter( 'style_loader_src', 'vc_remove_wp_ver_css_js', 9999 );
add_filter( 'script_loader_src', 'vc_remove_wp_ver_css_js', 9999 );






/* Gravity Form Error Popup
 --------------------------------------------------------------------------------------- */

add_filter("gform_validation_message_1", "change_message", 10, 2);
function change_message($message, $form){
    return '<script type="text/javascript">
                alert( "There has been an error in your submission. Make sure all fields are filled out and your email address is valid." );
                document.getElementById("footer-form").scrollIntoView();
            </script>';
}




/* Force Gravity Forms to initilize scripts in the footer and ensure that the DOM is loaded before scripts are executed
 --------------------------------------------------------------------------------------- */
// add_filter( 'gform_init_scripts_footer', '__return_true' );
// add_filter( 'gform_cdata_open', 'wrap_gform_cdata_open', 1 );
// function wrap_gform_cdata_open( $content = '' ) {
//     if ( ( defined('DOING_AJAX') && DOING_AJAX ) || isset( $_POST['gform_ajax'] ) ) {
//         return $content;
//     }
//     $content = 'document.addEventListener( "DOMContentLoaded", function() { ';
//     return $content;
// }
// add_filter( 'gform_cdata_close', 'wrap_gform_cdata_close', 99 );
// function wrap_gform_cdata_close( $content = '' ) {
//     if ( ( defined('DOING_AJAX') && DOING_AJAX ) || isset( $_POST['gform_ajax'] ) ) {
//         return $content;
//     }
//     $content = ' }, false );';
//     return $content;
// }

add_action( 'wp_footer', 'ae_wp_footer_action' );
function ae_wp_footer_action(){
    $wp_scripts = wp_scripts();
    if ( is_array( $wp_scripts->queue ) ) {
        if ( in_array( 'gform_recaptcha', $wp_scripts->queue ) ) {
            $wp_scripts->dequeue( 'gform_recaptcha' );
        }
    }
}

add_action( 'wp_head', 'ae_wp_head_action' );
function ae_wp_head_action(){
    printf( '<script type="text/javascript" src="%s"></script>', 'https://www.google.com/recaptcha/api.js?hl=en&render=explicit' );
}





add_filter( 'wp_schema_pro_schema_meta_fields', 'my_extra_schema_field' );


function my_extra_schema_field( $fields ) {
    $fields['bsf-aiosrs-review']['subkeys']['schema-type']['choices']['bsf-aiosrs-legal-service'] = esc_html__( 'Legal Service', 'wp-schema-pro' 
    );

    return $fields;
}
add_filter( 'wp_schema_pro_schema_item_type_recommended', 'my_extra_review_schema_field' );
	
/**
 * Add fields for mapping.
 *
 * @param  array $fields Mapping fields array.
 * @return array
 */
function my_extra_review_schema_field( $fields ) {
	$fields['bsf-aiosrs-legal-service'] = array(
						'subkeys' => array(
							'name'          => array(
								'label'    => esc_html__( 'Legal Service Name', 'wp-schema-pro' ),
								'type'     => 'text',
								'default'  => 'post_title',
								'required' => true,
							),
							'image'             => array(
								'label'   => esc_html__( 'Legal Service Image', 'wp-schema-pro' ),
								'type'    => 'image',
								'default' => 'featured_img',
							),
						),
					);


	return $fields;
}

/* SHORTCODES */

function video_block_function( $atts = array(), $content = null ){
	$content = do_shortcode($content);
	$show_schema = (isset($atts['show-schema']) && $atts['show-schema'] == 'false') ? false : true;
	$show_video = (isset($atts['show-video']) && $atts['show-video'] == 'false') ? false : true;
	$float = (isset($atts['float'])) ? $atts['float'] : '';
	$width = (isset($atts['width'])) ? str_replace('px', '', $atts['width']) : '';
	$id = (isset($atts['video'])) ? $atts['video'] : false;
	$url = (strpos($id, '.be/')) ? $id : 'https://youtu.be/' . $id;
	if ($id){
		$cust_class = 'class_hold_video_' . $float . $width;
		$style = '';
		if ( $cust_class !== 'class_hold_video_' ){
			$style .= '<style>.' . $cust_class . '{';
			$style .= ($float) ? 'float:' . $float . ';' : '';
			$style .= ($width) ? 'width:' . $width . 'px;' : '';
			$style .= 'max-width:100%;}</style>';
		}
		$classes = ($style !== '') ? 'video-cont-alt ' . $cust_class : '' ;
		$curl = curl_init('https://www.youtube.com/oembed?url=' . $url . '&format=json');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$video_info = json_decode(curl_exec($curl), true);
		curl_close($curl);
		$video_schema = '<script type="application/ld+json">{"@context": "https://schema.org", "@type": "VideoObject", "name": "' . ( (isset($atts['title'])) ? $atts['title'] : $video_info['title']) . '", "description": "' . ( (isset($atts['description'])) ? $atts['description'] : $video_info['title']) . '", "thumbnailUrl": [ "' . $video_info['thumbnail_url'] . '" ], "embedUrl": "' . get_permalink() . '", "uploadDate": "' . get_the_date() . '", "contentUrl": "' . $url . '"}</script>';
		$video_cont = $style . '<div class="' . $classes . '"><div class="youtube-player">' . $video_info['html'] . '</div>';
		$output = (($show_video) ? $video_cont : '') . (($show_schema) ? $video_schema : '');
		return (isset($atts['show-title']) && $atts['show-title'] == 'true') ? $output . '<h3 align="center">' . $title . '</h3></div>' : $output . '</div>';
	}else{
		return null;
	}
}

add_shortcode('video_block', 'video_block_function');
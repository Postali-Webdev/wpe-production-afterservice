<?php
/*
 * Template for single blog posts.
 */
?>

<?php get_header();?>

    <div class="blog-page">
        <div class="blog-main">
            <h1><?php the_title();?></h1>

            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

                <p class="blog-time">Posted by Gregory M. Rada <span>|</span> <?php the_time('F j, Y'); ?> <span>|</span> <?php the_category(',');?></p>
                <?php the_content();?>

            <?php endwhile; else : ?>
                <p><?php ( 'Sorry, no posts matched your criteria.' ); ?></p>
            <?php endif; ?>

        </div>

        <div class="blog-sidebar">
            <?php dynamic_sidebar( 'blog-sidebar' ); ?>
        </div>
    </div>

<?php get_footer();?>
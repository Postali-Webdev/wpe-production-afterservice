<?php
/*
 * 404 Error Page
 */
?>

<?php get_header();?>

    <div class="default-page">
        <div class="default-page-container">
            <div class="default-main">
                <h1 class="internal-page-title">404</h1>

                <p>The page you were looking for appears to have been moved, deleted or does not exist.
                    You could <a class="go-back" onclick="history.back();" href="#">go back</a> to where
                    you were or head straight to our <a href="<?php echo site_url();?>">home page</a>
                </p>

            </div>

            <div class="default-sidebar">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/pa-stamp.png">
                <?php wp_nav_menu( array('menu' => 'Practice Areas Menu' )); ?>
            </div>
        </div>
    </div>

<?php get_footer();?>
<?php
/*
 * Template Name: Practice Areas Grid
 */
?>

<?php get_header();?>

    <div class="practice-areas-grid-page">
        <div class="practice-areas-grid-page-container">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/int-pa-stamp.png">
            <h1>Practice <span>Areas</span></h1>
			
            <div class="practice-areas-grid">
                <?php wp_nav_menu( array('menu' => 'Practice Areas Menu' )); ?>
            </div>
        </div>
    </div>

<?php get_footer();?>
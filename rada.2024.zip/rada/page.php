<?php
/*
 * Default Template
 */
?>

<?php get_header();?>

    <div class="default-page">
        <div class="default-page-container">
            <div class="default-main">
                <h1><?php the_title();?></h1>

                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <?php the_content();?>
                <?php endwhile; else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
                <?php endif; ?>

            </div>

            <div class="default-sidebar">
                <div class="form-container" style="border: 1px #167ac6 solid; background:#e9f1f7">
                 <h3 style="font-family: 'Refrigerator Deluxe Bold';
    color: #366fa1; font-size: 46px! important; line-height: 46px; letter-spacing: 0px; padding-bottom: 10px;">Free Consultation</h3>
                <?php echo do_shortcode( '[gravityform id="2" title="false"]' ); ?>
                </div>
                <br>
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/pa-stamp.png">

                <br>
                <?php wp_nav_menu( array('menu' => 'Practice Areas Menu' )); ?>
                
                <script type="application/ld+json">{ "@context": "http://schema.org/", "@type": "LegalService", "location": { "@type": "Place", "address": { "@type": "PostalAddress", "streetAddress": "P.O. Box 371680 #4545", "addressLocality": "Denver", "addressRegion": "CO", "postalCode": "80237" } }, "priceRange":"Free consultation", "address": { "@type": "PostalAddress", "streetAddress": "P.O. Box 371680 #4545", "addressLocality": "Denver", "addressRegion": "CO", "postalCode": "80237" }, "geo": { "@type": "GeoCoordinates", "latitude": "39.638730", "longitude": "-104.899930" }, "areaServed": " Denver, CO", "description": "Nationwide Veteran Disability Lawyer - Gregory M. Rada", "founder": "Gregory M. Rada", "image": "https://afterservice.com/wp-content/themes/rada/images/hero-logo.svg", "telephone": "(800) 955-8596", "url": "https://afterservice.com/", "name": "After Service LLC", "email": "greg@afterservice.com", "aggregateRating": { "@type": "AggregateRating", "bestRating": "5", "worstRating": "1", "ratingCount": "71", "ratingValue": "5" }, "review": [ { "@context": "http://schema.org/", "@type": "Review", "reviewBody": "Greg is an amazing lawyer that you should hire! I wanted someone who was also in the military and could understand how the VA system works to help me win my appeal for my TDIU benefits, and he managed to win my case. Thanks again!", "itemReviewed": { "@type": "LegalService", "name": "After Service LLC", "telephone": "(800) 955-8596", "address": { "@type": "PostalAddress", "streetAddress": "P.O. Box 371680 #4545", "addressLocality": " Denver", "addressRegion": "CO", "postalCode": "80237" }, "priceRange":"Free consultation", "image": "https://afterservice.com/wp-content/themes/rada/images/hero-logo.svg" }, "author": { "@type": "Person", "name": "Pauline O'Connell" }, "reviewRating": { "@type": "Rating", "worstRating": "1", "ratingValue": "5", "bestRating": "5" } } ] }</script>

<br><br>
<h3 style="font-family: 'Refrigerator Deluxe Bold';
    color: #366fa1; font-size: 28px! important; line-height: 35px; letter-spacing: 0px; padding-bottom: 10px;">Client Review</h3>
<p style="font-family: 'Crimson Text Regular'; color: #1b2141; font-size: 17px; line-height: 35px; padding-bottom: 32px;">"Greg is an amazing lawyer that you should hire! I wanted someone who was also in the military and could understand how the VA system works to help me win my appeal for my TDIU benefits, and he managed to win my case. Thanks again!"<br />
<b>Pauline O'Connell</b><br /> <img src="/wp-content/uploads/2022/12/xtars.png" alt="Client Review" /></p>  
            </div>
        </div>
    </div>
<style>
#gform_fields_2 li {
    flex-basis: 100%;
    position: relative;
}

#gform_fields_2 li input {
    width: 100%;
    height: 60px;
    border: none;
    background-color: #fff;
    padding: 0 20px;
    font-family: 'Crimson Text Regular';
    color: #1b2141;
    font-size: 17px;
    margin-top: 10px;
}

#gform_fields_2 li textarea {
    width: 100%;
    height: 154px;
    border: none;
    background-color: #fff;
    padding: 27px 20px;
    font-family: 'Crimson Text Regular';
    color: #1b2141;
    font-size: 17px;
    margin-top: 22px;
    resize: none;
}
#gform_submit_button_2 {
    width:100%;
    background-color: #1b2141;
    height: 54px;
    font-family: 'Refrigerator Deluxe Regular';
    color: #fff;
    font-size: 29px;
    text-transform: uppercase;
        cursor: pointer;
    -webkit-transition: all .25s ease-in-out;
    -moz-transition: all .25s ease-in-out;
    -ms-transition: all .25s ease-in-out;
    -o-transition: all .25s ease-in-out;
    transition: all .25s ease-in-out;
       
}
</style>
<?php get_footer();?>
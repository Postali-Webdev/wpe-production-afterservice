/* Functions that run on the internal pages only. */

jQuery(document).ready(function(){


    /* Blog H1's
     --------------------------------------------------------------------------------------- */

    if ( jQuery(".blog-main h1").text().length > 28 ) {
        jQuery(".blog-main h1").addClass("blog-title-long");
    }


    /* End Document Ready
     --------------------------------------------------------------------------------------- */

});
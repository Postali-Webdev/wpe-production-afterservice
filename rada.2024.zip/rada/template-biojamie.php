<?php
/*
 * Template Name: Bio Jamie
 */
?>

<?php get_header();?>

    <div class="bio-page">
        <div class="bio-page-container">
            <div class="bio-left">
                <h1>Jamie B.<span>Szmurlo</span></h1>
                <img class="tablet-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <img class="mobile-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_content(); ?>
                <?php endwhile; // end of the loop. ?>
            </div>

            <div class="bio-right">
              <img class="desktop-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
				
				<h4>Contact</h4>
                <h5>jamie@afterservice.com</h5>

              <h4>EDUCATION</h4>
              <h5>MacCormack College</h5>
              <p>A.A., Paralegal Studies</p>

              <h5>Central European University</h5>
              <p>M.A., International Relations and European Studies</p>
              
              <h5>University of Illinois at Chicago</h5>
              <p>B.A., Political Science with Biology Minor</p>

            </div>
        </div>
    </div>

<?php get_footer();?>
<?php
/*
 * Template Name: Bio Victoria
 */
?>

<?php get_header();?>

    <div class="bio-page">
        <div class="bio-page-container">
            <div class="bio-left">
                <h1>Victoria M.<span>Rada</span></h1>
                <img class="tablet-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <img class="mobile-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_content(); ?>
                <?php endwhile; // end of the loop. ?>
            </div>

            <div class="bio-right">
              <img class="desktop-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">

				<h4>Contact</h4>
                <h5>victoria@afterservice.com</h5>
				
                <h4>EDUCATION</h4>
                <h5>University of California Santa Cruz</h5>
                <p>Bachelors in Legal Studies</p>

                <h5>University of Connecticut School of Law</h5>
                <p>J.D.</p>

            </div>
        </div>
    </div>

<?php get_footer();?>
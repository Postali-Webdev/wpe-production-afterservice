<?php
/*
 * Template Name: About
 */
?>

<?php get_header();?>

    <div class="about-page">
        <div class="about-page-container">
            <div class="about-left">
                <h1>Firm <span>overview</span></h1>

                <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_content(); ?>
                <?php endwhile; // end of the loop. ?>
            </div>

            <div class="about-right">
                <div class="about-right-content">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/int-overview-burst.svg">
                    <h4>Representing<br>veterans<br>nationwide</h4>
                     <div class="about-play-button video-trigg">
                        <p><span>click to watch</span> our video</p>
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/int-overview-playbutton.png">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/int-overview-playbutton-hover.png">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script charset="ISO-8859-1" src="//fast.wistia.com/assets/external/E-v1.js" async></script>

<?php get_footer();?>
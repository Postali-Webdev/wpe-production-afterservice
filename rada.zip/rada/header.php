<!DOCTYPE html>
<html lang="en-US">

<head>

	<meta charset="utf-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1" />
	<meta name = "format-detection" content = "telephone=no">
    <link rel="icon" type="image/png" href="<?php echo get_stylesheet_directory_uri(); ?>/images/favicon.png">

	<title><?php bloginfo('name'); ?></title>

<?php wp_head(); ?>

    <!-- Header Codes
    --------------------------------------------------------------------------------------- -->
    <?php the_field('analytics_code', 'option'); ?>

</head>

	<body <?php body_class(); ?> >
		
		<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5G6K5VQ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


		<header>
			<div class="header-top">
                <div class="header-top-logo">
                    <a href="<?=get_permalink(4); ?>">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero-logo.svg">
                    </a>
                </div>

                <div class="header-top-nav">
                    <?php wp_nav_menu( array('menu' => 'Main Menu' )); ?>
                </div>

                <div class="header-top-number">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero-icon.svg">
                    <a href="tel:<?php echo str_replace(['-', '(', ')', ' '], '', get_field('firm_number', 'option')); ?>"><?php the_field('firm_number', 'option'); ?></a>
                    <p><span>FREE PHONE</span> CONSULTATIONS</p>
                </div>

                <div class="header-top-menu-button">
                    <div class="menu-button-content">
                        <p>MENU</p>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            </div>

            <div class="banner">
                <div class="banner-top">
                    <h2>A veteran <span>for Veterans.</span></h2>
                    <p>proven results <span>&bull;</span> direct communication <span>&bull;</span> no fees unless you win</p>

                    <a href="#footer-form" class="mobile-only">TAP FOR A FREE CONSULTATION</a>
                </div>

                <div class="banner-bottom">
                    <div class="banner-box banner-box-1">
                        <div class="banner-box-1-top">
                            <div class="banner-play-button video-trigg">
                                 <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero-video-playbutton.png">
                                <img class="play-button-chunks" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero-video-playbutton-chunks.png">
                            </div>
                        </div>

                        <div class="banner-box-1-bot">
                             <span>WATCH THE VIDEO</span>
                            <p>about the firm</p>
                        </div>
                    </div>

                    <a href="#footer-form">
                        <div class="banner-box banner-box-2">
                            <h4>START<br>HERE.</h4>
                            <p><em><i>click</i><b>tap</b> here</em> to get your<br> <span>free consultation</span> without risk to you or your family</p>

                            <div class="banner-box-2-button">
                                <img class="banner-box-2-button-circle svg" src="<?php echo get_stylesheet_directory_uri(); ?>/images/button-circle-01.svg">
                                <img class="banner-box-2-button-arrow svg" src="<?php echo get_stylesheet_directory_uri(); ?>/images/button-arrow-01.svg">
                            </div>
                        </div>
                    </a>
                    </div>

                    <a href="/the-firm/"><p class="mobile-button-text mobile-only">LEARN MORE ABOUT OUR FIRM</p></a>
                </div>

                <div class="scroll-down">
                    <a href="#section-1">scroll down</a>
                </div>
            </div>
		</header>






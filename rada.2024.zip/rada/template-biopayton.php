<?php
/*
 * Template Name: Bio Payton
 */
?>

<?php get_header();?>

    <div class="bio-page">
        <div class="bio-page-container">
            <div class="bio-left">
                <h1>Payton B.<span>Martinez</span></h1>
                <img class="tablet-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <img class="mobile-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_content(); ?>
                <?php endwhile; // end of the loop. ?>
            </div>

            <div class="bio-right">
              <img class="desktop-only" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Headshot">
				
				<h4>Contact</h4>
                <h5>payton@afterservice.com</h5>

              <h4>EDUCATION</h4>
              <h5>University of Denver, Sturm College of Law</h5>
              <p>J.D. with Public Good Distinction</p>

              <h5>University of Colorado at Boulder</h5>
              <p>B.A., Religious Studies & International Affairs</p>
              <h4>Admissions</h4>
              
              <h5>State of Colorado</h5>
              <h5>Veterans Affairs Accredited Attorney </h5>

            </div>
        </div>
    </div>

<?php get_footer();?>
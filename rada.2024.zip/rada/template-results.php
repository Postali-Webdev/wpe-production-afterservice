<?php
/*
 * Template Name: Results
 */
?>

<?php get_header();?>

    <div class="results-page">
        <div class="results-page-container">
            <h1>Case <span>Results</span></h1>

            <div class="results-content">
                <div class="results-left">
                    <?php if( have_rows('results_left_column') ): while ( have_rows('results_left_column') ) : the_row(); ?>
                        <div class="result-item">
                            <h3><?php the_sub_field('result_header'); ?></h3>
                            <div class="result-item-content">
                                <?php the_sub_field('result_content'); ?>
                            </div>
                            <h4><?php the_sub_field('result_author'); ?></h4>
                        </div>
                    <?php endwhile; else : endif; ?>
                </div>

                <div class="results-right">
                    <?php if( have_rows('results_right_column') ): while ( have_rows('results_right_column') ) : the_row(); ?>
                        <div class="result-item">
                            <h3><?php the_sub_field('result_header'); ?></h3>
                            <div class="result-item-content">
                                <?php the_sub_field('result_content'); ?>
                            </div>
                            <h4><?php the_sub_field('result_author'); ?></h4>
                        </div>
                    <?php endwhile; else : endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php get_footer();?>
<?php
/*
 * Template Name: Contact
 */
?>

<?php get_header();?>

    <div class="contact-page">
        <h1>Contact <span>Me</span></h1>
        <div class="footer-info-container">
            <div class="footer-info-box">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/footer-icon-1.svg">
                <h4>PHONE</h4>
                <h5>NEW CLIENTS: <a href="tel:<?php echo str_replace(['-', '(', ')', ' '], '', get_field('firm_number', 'option')); ?>"><?php the_field('firm_number', 'option'); ?></a></h5>
				<h5>EXISTING CLIENTS: <a href="tel:8448387529">(844) 838-7529</a></h5>
                <h5>FAX <a href="tel:<?php echo str_replace(['-', '(', ')', ' '], '', get_field('firm_fax_number', 'option')); ?>"><?php the_field('firm_fax_number', 'option'); ?></a></h5>
            </div>

            <div class="footer-info-box">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/footer-icon-2.svg">
                <h4>OFFICE</h4>
                <p><?php the_field('address_line_1', 'option'); ?></p>
                <p><?php the_field('address_line_2', 'option'); ?></p>
                <h5>REPRESENTING VETERANS NATIONWIDE</h5>
				<p><a href="/schedule-an-appointment/" class="btn">Schedule an appointment</a></p>
            </div>

            <div class="footer-info-box">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/footer-icon-3.svg">
                <h4>SOCIAL</h4>
				
				<?php if( get_field('facebook_link', 'option') ): ?>
                <a href="<?php the_field('facebook_link', 'option'); ?>" target="_blank">facebook</a>
				<?php endif; ?>
                
				<?php if( get_field('google_plus_link', 'option') ): ?>
				<a href="<?php the_field('google_plus_link', 'option'); ?>" target="_blank">google +</a>
				<?php endif; ?>
				
				<?php if( get_field('linkedin_link', 'option') ): ?>
					<a href="<?php the_field('linkedin_link', 'option'); ?>" target="_blank">linkedin</a>
				<?php endif; ?>
            </div>
        </div>
    </div>
		<!-- removed map
    <div class="contact-page-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3067.94585541567!2d-105.20404548462452!3d39.74086707944934!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x876b9ad2c3bbb85f%3A0x5f5da8ccc96d7e92!2sGolden%2C+CO+80402!5e0!3m2!1sen!2sus!4v1513919767804" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
	-->

<?php get_footer();?>